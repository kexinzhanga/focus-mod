# 专注光环 · Focus Aura 1.0

蓝色弱专注：呼吸光环、三个绕行光点。
金色强专注：双层反向旋转的符文光环、绕行光点和上浮粒子。
光环位于 Token 边缘，中央透明。宽高跟随角色图像边界，非方形图像呈椭圆。

## 安装

ZIP 不能直接导入 Owlbear Rodeo。先解压，将 dist 文件夹内的内容部署到可公开访问的 HTTPS 静态网站根目录。
部署后应能直接打开 https://你的域名/manifest.json，无登录墙，并允许 Owlbear 的 iframe 嵌入。
在 Owlbear Rodeo 的扩展管理中添加这个 manifest.json 网址，再在房间启用此扩展。
官方托管指南：https://docs.owlbear.rodeo/extensions/tutorial-sharing-your-extension/hosting-your-extension/

## 使用

打开场景，选中角色层上的一个或多个图像 Token。
点击 Token 上下文菜单中的“弱专注”“强专注”“关闭专注”，或从扩展面板切换。
专注状态写入 Token 元数据；每位参与者的扩展在本地绘制特效。关闭面板不会停止效果。
修改 Token 的操作受 Owlbear 原有编辑权限限制；建议先用 GM 测试。
切换状态会替换旧状态，不会叠加。关闭只移除本插件的状态，不修改其他插件数据。
隐藏和删除 Token 时，渲染器同步隐藏或移除相应光环。
卸载前可选中相关 Token 关闭专注；卸载后元数据不会自动清除，但不会继续渲染。

## 开发

安装 Node.js 22.12 或更新的受支持版本，然后运行：

```sh
npm ci
npm test
npm run build
npm run dev
```

dist 是构建产物，src 是源代码。没有外部图片、字体或运行时 CDN 依赖。
index.html 面板中的 CSS 圆环仅是样式示意；地图上的实际效果由 shader.ts 中的 SkSL 生成。
Effect API 是 Owlbear 的实验性接口：https://docs.owlbear.rodeo/extensions/reference/items/effect/

## 验证范围

已进行 TypeScript 检查、生产构建和模拟 SDK 的自动化测试。
尚未在真实 Owlbear 房间联调，SkSL 实际渲染与多客户端行为需要安装后验收。
验收：弱/强/关闭、多选、移动与缩放、隐藏/显示、删除、刷新恢复、切场景，以及 GM/玩家双窗口同步和权限。
