import OBR, {type Item} from '@owlbear-rodeo/sdk';
export const KEY = 'com.kexin.focus-aura/state';
export const FX = 'com.kexin.focus-aura/effect';
export type Mode = 'weak' | 'strong' | 'off';
export function modeOf(item: Item): Mode {
  const value = item.metadata[KEY];
  return value === 'weak' || value === 'strong' ? value : 'off';
}
export function isToken(item: Item) {return item.type === 'IMAGE' && item.layer === 'CHARACTER';}
export async function setMode(ids: string[], mode: Mode) {
  if (!await OBR.scene.isReady()) throw new Error('请先打开场景。');
  const tokens = (await OBR.scene.items.getItems(ids)).filter(isToken);
  if (!tokens.length) throw new Error('请先选中角色层上的 Token。');
  await OBR.scene.items.updateItems(tokens, drafts => {
    for (const token of drafts) {
      if (mode === 'off') delete token.metadata[KEY];
      else token.metadata[KEY] = mode;
    }
  });
  return tokens.length;
}
