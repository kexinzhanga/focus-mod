// SkSL: transparent center; premultiplied output, no scene sampling.
export function focusShader(strong: boolean) {return `
uniform vec2 size;
uniform float time;
float ring(float r, float target, float width) {
  return 1.0 - smoothstep(width, width + 0.012, abs(r-target));
}
half4 main(float2 coord) {
  vec2 p = (coord / size - 0.5) * 2.0;
  float r = length(p);
  float a = atan(p.y,p.x);
  float pulse = 0.72 + 0.22 * sin(time * 1.8);
  float light = ring(r,0.89,0.012) * pulse;
  light += exp(-abs(r-0.89)*65.0) * 0.16;
  ${strong ? `
  float runes = pow(max(0.0,cos(a*16.0-time*0.9)),12.0);
  light += ring(r,0.77,0.022) * (0.2+0.65*runes);
  light += ring(r,0.91,0.035) * pow(max(0.0,cos(a*12.0+time*0.75)),18.0)*0.6;
  for (int i=0;i<8;i++) {
    float phase = fract(time*0.14+float(i)*0.127);
    float x = sin(float(i)*8.73)*0.8;
    vec2 pos = vec2(x,0.65-phase*1.45);
    float spark = exp(-length(p-pos)*150.0)*sin(phase*3.14159);
    light += spark * smoothstep(0.55,0.74,r);
  }
  ` : ''}
  for(int i=0;i<${strong ? 6 : 3};i++) {
    float angle = time*${strong ? '0.65' : '0.35'}+float(i)*${strong ? '1.0472' : '2.0944'};
    vec2 pos = vec2(cos(angle),sin(angle))*0.89;
    light += exp(-length(p-pos)*95.0)*0.8;
  }
  float alpha = clamp(light,0.0,0.95)*(1.0-smoothstep(0.97,1.0,r));
  vec3 color = ${strong ? 'vec3(1.0,0.72,0.22)' : 'vec3(0.28,0.76,1.0)'};
  return half4(color*alpha,alpha);
}`;}
