import OBR from '@owlbear-rodeo/sdk';
import {isToken, setMode, type Mode} from './shared';
import './style.css';
const selection = document.querySelector<HTMLParagraphElement>('#selection')!;
const status = document.querySelector<HTMLParagraphElement>('#status')!;
const buttons = Array.from(document.querySelectorAll<HTMLButtonElement>('button'));
let busy = false;
let ready = false;
function disabled(value: boolean) {buttons.forEach(button => button.disabled=value);}
disabled(true);
async function refresh() {
  ready = await OBR.scene.isReady();
  if (!ready) {selection.textContent='请先打开一个场景'; disabled(true); return;}
  const ids = await OBR.player.getSelection() ?? [];
  const count = ids.length ? (await OBR.scene.items.getItems(ids)).filter(isToken).length : 0;
  selection.textContent=count ? `已选中 ${count} 个角色 Token` : '请在地图上选中角色 Token';
  disabled(!count || busy);
}
if (!OBR.isAvailable) {
  selection.textContent='外观预览 · 请在 Owlbear Rodeo 中安装使用';
} else OBR.onReady(async () => {
  await refresh();
  OBR.player.onChange(() => void refresh().catch(showError));
  OBR.scene.onReadyChange(() => void refresh().catch(showError));
  OBR.scene.items.onChange(() => void refresh().catch(showError));
});
function showError(error: unknown) {status.textContent = error instanceof Error ? error.message : '操作失败，请检查权限后重试。';}
buttons.forEach(button => button.addEventListener('click',async () => {
  if (busy || !ready) return;
  busy=true; disabled(true);
  try {
    const mode=button.dataset.mode as Mode;
    const count = await setMode(await OBR.player.getSelection() ?? [],mode);
    status.textContent=`${count} 个角色：${mode==='off'?'已关闭':mode==='weak'?'弱专注已开启':'强专注已开启'}`;
  } catch(error) {showError(error);}
  finally {busy=false; await refresh().catch(showError);}
}));
