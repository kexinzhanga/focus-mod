import OBR, {buildEffect} from '@owlbear-rodeo/sdk';
import {KEY, FX, isToken, modeOf, setMode, type Mode} from './shared';
import {focusShader} from './shader';
let running=false;
let again=false;
async function sync() {
  again=true;
  if (running) return;
  running=true;
  try {
    while(again) {
      again=false;
      if (!await OBR.scene.isReady()) break;
      const tokens=(await OBR.scene.items.getItems()).filter(item=>isToken(item)&&modeOf(item)!=='off');
      const locals=(await OBR.scene.local.getItems()).filter(item=>item.metadata[FX]===true);
      const wanted=new Map(tokens.map(token=>[token.id,token]));
      const remove=locals.filter(effect=>!effect.attachedTo || !wanted.has(effect.attachedTo));
      if(remove.length) await OBR.scene.local.deleteItems(remove.map(item=>item.id));
      for(const token of tokens) {
        const mode=modeOf(token);
        const existing=locals.find(item=>item.attachedTo===token.id);
        if(existing) {
          if(existing.metadata[KEY]!==mode || existing.visible!==token.visible) {
            await OBR.scene.local.updateItems([existing.id],drafts=>{
              for(const item of drafts) {
                item.visible=token.visible;
                item.metadata[KEY]=mode;
                if(item.type==='EFFECT') Object.assign(item,{sksl:focusShader(mode==='strong')});
              }
            });
          }
        } else {
          const effect=buildEffect().name(mode==='strong'?'强专注':'弱专注')
            .effectType('ATTACHMENT').attachedTo(token.id)
            .sksl(focusShader(mode==='strong')).layer('ATTACHMENT')
            .locked(true).disableHit(true).visible(token.visible)
            .metadata({[FX]:true,[KEY]:mode}).build();
          await OBR.scene.local.addItems([effect]);
        }
      }
    }
  } finally {running=false;}
}
function schedule() {void sync().catch(error=>console.error('Focus Aura:',error));}
OBR.onReady(async()=>{
  OBR.scene.items.onChange(schedule);
  OBR.scene.onReadyChange(schedule);
  for(const mode of ['weak','strong','off'] as Mode[]) {
    await OBR.contextMenu.create({
      id:`${KEY}/${mode}`,
      icons:[{icon:'/icon.svg',label:mode==='weak'?'弱专注':mode==='strong'?'强专注':'关闭专注',filter:{every:[{key:'type',value:'IMAGE'},{key:'layer',value:'CHARACTER'}]}}],
      onClick:async context=>{
        try {await setMode(context.items.map(item=>item.id),mode);}
        catch(error) {await OBR.notification.show(error instanceof Error?error.message:'操作失败，请检查角色权限。','ERROR');}
      }
    });
  }
  schedule();
});
