import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import ts from 'typescript';
import vm from 'node:vm';
function load(file,deps={}) {
 const output=ts.transpileModule(fs.readFileSync(new URL('../src/'+file,import.meta.url),'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
 const exports={};vm.runInNewContext(output,{exports,require:name=>deps[name],console});return exports;
}
test('states are exclusive, off preserves unrelated metadata, non-tokens ignored',async()=>{
 const tokens=[{id:'a',type:'IMAGE',layer:'CHARACTER',metadata:{other:42}},{id:'b',type:'IMAGE',layer:'MAP',metadata:{}}];
 const obr={scene:{isReady:async()=>true,items:{getItems:async()=>tokens,updateItems:async(items,fn)=>fn(items)}}};
 const api=load('shared.ts',{'@owlbear-rodeo/sdk':{default:obr}});
 assert.equal(await api.setMode(['a','b'],'weak'),1);assert.equal(api.modeOf(tokens[0]),'weak');
 await api.setMode(['a'],'strong');assert.equal(api.modeOf(tokens[0]),'strong');
 await api.setMode(['a'],'off');assert.deepEqual(tokens[0].metadata,{other:42});assert.deepEqual(tokens[1].metadata,{});
});
test('no scene and empty selection fail safely',async()=>{
 const obr={scene:{isReady:async()=>false,items:{getItems:async()=>[]}}};
 const api=load('shared.ts',{'@owlbear-rodeo/sdk':{default:obr}});
 await assert.rejects(()=>api.setMode([],'weak'),/场景/);
 obr.scene.isReady=async()=>true;await assert.rejects(()=>api.setMode([],'weak'),/Token/);
});
test('both shaders are distinct and keep transparent premultiplied output',()=>{
 const {focusShader}=load('shader.ts');const weak=focusShader(false),strong=focusShader(true);
 assert.notEqual(weak,strong);assert.match(strong,/runes/);assert.doesNotMatch(weak,/runes/);
 for(const shader of [weak,strong]){assert.match(shader,/color\*alpha,alpha/);assert.match(shader,/uniform float time/);}
});
test('renderer creates, updates, hides and removes only its own effects',async()=>{
 const callbacks={};let items=[{id:'a',type:'IMAGE',layer:'CHARACTER',visible:true,metadata:{}}];let local=[];let counter=0;
 const obr={onReady:fn=>{callbacks.ready=fn;},contextMenu:{create:async()=>{}},scene:{isReady:async()=>true,onReadyChange:fn=>{callbacks.scene=fn;},items:{onChange:fn=>{callbacks.items=fn;},getItems:async()=>items},local:{getItems:async()=>local,addItems:async values=>{local.push(...values);},deleteItems:async ids=>{local=local.filter(x=>!ids.includes(x.id));},updateItems:async(ids,fn)=>fn(local.filter(x=>ids.includes(x.id)))}}};
 const buildEffect=()=>{const data={id:'fx'+counter++,type:'EFFECT'};const builder=new Proxy({},{get:(_,key)=>key==='build'?()=>data:value=>{data[key]=value;return builder;}});return builder;};
 const sdk={default:obr,buildEffect};const shared=load('shared.ts',{'@owlbear-rodeo/sdk':sdk});
 items[0].metadata[shared.KEY]='weak';
 load('background.ts',{'@owlbear-rodeo/sdk':sdk,'./shared':shared,'./shader':load('shader.ts')});
 const flush=()=>new Promise(resolve=>setTimeout(resolve,10));
 await callbacks.ready();await flush();assert.equal(local.length,1);assert.equal(local[0].attachedTo,'a');assert.equal(local[0].disableHit,true);
 callbacks.items();await flush();assert.equal(local.length,1);
 items[0].metadata[shared.KEY]='strong';items[0].visible=false;callbacks.items();await flush();assert.match(local[0].sksl,/runes/);assert.equal(local[0].visible,false);
 local.push({id:'unrelated',metadata:{}});items=[];callbacks.items();await flush();assert.deepEqual(local.map(x=>x.id),['unrelated']);
});
